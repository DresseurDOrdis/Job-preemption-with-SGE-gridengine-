#!/bin/bash
# Script ecrit par Philippe ZELLER le 31 mai 2011.
# Il va de pair avec le script "resume_method.sh"

# WARNING: En raison de la syntaxe "< <(...)" ce script necessite une version recente de bash.

ici=$(hostname); ici_short=${ici%%.*} ; ici_short=${ici_short/*tintin/tintin}

#********* CUSTOMISATION: suivant les machines, ajuster les lignes suivantes...        *************
SGE_bin=$SGE_ROOT/bin/lx26-amd64
JobCtrlDir=$TMPDIR
QueuePrio=prio  # tintin: mot-cle identifiant la queue pour laquelle "resume" est immediat
QueueMixte=big  # tintin: mots-cles identifiant la queue parfois subordonnee, parfois prioritaire.
JobDataBuild=/home/sgeadmin/utilitaires/JobDataBuild.sh
AFFICHER_CHARGE=TRUE     # fait un "uptime" au moment de la suspension

case ${ici_short} in
   tintin*)
coresPerNode=32
NseuilRef=32.9     # pour tintin, machine de reference: Opteron 6136 sous CentOS 5.5
NseuilRef_special=32.4
JobDataBuild=/home/sgeadmin/utilitaires/JobDataBuild.sh    # sur tintin
     ;;
esac
#*********       .... jusqu ici.         ***********************************************************
NseuilRef_special=${NseuilRef_special:-NseuilRef}


function etat_affiche_par_SGE {
  eval "$SGE_bin/qstat -u $(whoami) -q ${QUEUE}@$ici | awk '"'$1 ==' $JOB_ID ' {print  $5}'"'"
}

fichier_sortie=./SGE.${HOSTNAME%.*}.$JOB_ID.suspen.$(date +%s)

# 1ere possibilite pour la redirection de la sortie standard: inclut le preambule
# {

# Preambule: il peut s agir d un dummy signal visant juste a mettre a jour l affichage SGE
ls -t $JobCtrlDir/SGE_harak* 1>/dev/null 2>&1 
if [ $? -eq 0 ] ; then
#	echo "ceci est un harakiri, aucun signal n est envoye. " 
	rm $JobCtrlDir/SGE_harak*
	exit 0
fi

# 2eme possibilite pour la redirection de la sortie standard: exclut le preambule
{

echo
ici=$(hostname); ici_short=${ici%%.*}; ici_short=${ici_short/*tintin/tintin}
echo "hello from Suspendator at " ${ici} "    on " $(date)
echo
job_pid=$1           
moi=$(whoami)
echo '$(hostname)='$ici
echo '$(whoami)='$moi
echo "JOB_ID =" $JOB_ID
echo "job_pid=" $job_pid
echo "TMPDIR=" $TMPDIR
echo "PWD=" $PWD
echo "PE_HOSTFILE=" $PE_HOSTFILE
echo "PE=" $PE
echo "NHOSTS=" $NHOSTS
echo "NSLOTS=" $NSLOTS
echo "NQUEUES=" $NQUEUES
echo "Contenu du pe_hostfile :"
cat $PE_HOSTFILE
echo


cadR=$JobCtrlDir/SGE_resu_lock.$moi.$JOB_ID.
# Valeurs par defaut, necessaires pour les tests d'existence.  
suff=$(date +%s)$(date +%N)
cadU=$(echo $cadR | sed -e s/resu/subord/)
Ucadenas=${cadU}${suff}
Scadenas=""

# Pour info, afficher la charge des noeuds
if [[ blabla$AFFICHER_CHARGE == blablaTRUE ]]; then 
	if [[ -f $PE_HOSTFILE ]]; then 
		while read line; do
	 		hote=`echo $line | cut -d" " -f1 `
			echo $hote | grep $ici_short 2>/dev/null
			if [ $? -eq 0 ] ; then
				uptime
			else
				ssh -l $moi ${hote} 'echo $(hostname) " " $(uptime)' &
#				rsh -l $moi ${hote} 'echo $(hostname) " " $(uptime)' &
			fi
		done < $PE_HOSTFILE
	else
		uptime
	fi
fi

Rcadenas=""
for k in $(ls -r $cadR* 2>/dev/null) ; do Rcadenas=$k; break; done
# Annihilation d un eventuel signal "resume" en attente d etre envoye.
# Recherche de cadenas pose par un signal "resume" en attente
#  et, le cas echeant, pose d un cadenas de suspension.
#  11/07/2012: en principe ce cas ne devrait plus se presenter, car
#              resume_meth.sh force l affichage SGE a passer en "s", suite a quoi 
#              SGE ne lance plus la procedure suspend_meth.sh .
#              Il se presente quand meme quand la machine devient une mitraillette de signaux. 
if  [ x$Rcadenas != x ] ; then
	Scadenas=$(echo $Rcadenas | sed -e s/resu/susp/) 	
	touch $Scadenas
#	ls $Scadenas
	echo "Lock $Rcadenas present."
	while [ -f $Rcadenas ] ; do 
		sleep 1 
	done
	if  [ -f $Scadenas ] ; then
		echo "Bizarre: le cadenas de suspension est reste en place."
		rm $Scadenas
	fi
	echo "Le job $job_id a ete maintenu en suspension par annihilation de signaux"
	echo "bye bye, le " $(date)
	exit 0
fi


# Recherche des donnees de controle des processus.
if [ -f $JobCtrlDir/SGE_JobData ] ; then 
# 	Cas d un job SGE qui contient plusieurs commandes mpirun qui s enchainent. 
#   	Il faut tester si les donnees de controle sont bien celles du processus mpirun actuel.
	nf1=$JobCtrlDir/SGE_JobData
	treepm=$(pstree -Anlcp $job_pid | head -1)
	CURRENT_PS=${treepm##*(}; CURRENT_PS=${CURRENT_PS%)}
	if [[ x$CURRENT_PS = x ]] ; then 
		echo 'Absence de processus!'
		sleep 10
		treepm=$(pstree -Anlcp $job_pid | head -1)
		CURRENT_PS=${treepm##*(}; CURRENT_PS=${CURRENT_PS%)}
	fi
	echo $CURRENT_PS	
	nf2=/proc/${CURRENT_PS}
	nf3=$(ls -dt $nf1 $nf2 2>/dev/null | head -n1)
	if [[ $nf3 != $nf1 ]] ; then
		rm $JobCtrlDir/SGE_JobData
		. $JobDataBuild
	fi 
# test sur la version du script
	nf2=${JobDataBuild}
	nf3=$(ls -dt $nf1 $nf2 2>/dev/null | head -n1)
	if [[ $nf3 != $nf1 ]] ; then
		rm $JobCtrlDir/SGE_JobData
		. $JobDataBuild
	fi 
  else
	. $JobDataBuild 
fi

# Lecture du fichier SGE_JobData
il=0     # indice de ligne du fichier SGE_JobData
ih=0
while read line; do
	il=`expr $il + 1`
	if [[ $il -eq 1 ]] ; then
		read methode < <(echo $line)
	elif [[ $il -eq 2 ]] ; then
		read SCORRECT MDQ commentaire < <(echo $line)
	elif [[ $il -eq 3 ]] ; then
#		read  MPI_TYPE MPI_SIG_CMD MPI_SOCKET MPDJOBID MPICMD_PID < <(echo $line)
		read  MOT1     MOT2        MOT3       MOT4     MOT5        < <(echo $line)
	else
		ih=`expr $ih + 1`
		read hote[$ih] nslots[$ih] PrioEff[$ih] LOAD_CORR[$ih] PIDC[$ih] CONNEXION[$ih] < <(echo $line)
		Nseuil[$ih]=$(echo "scale=2; $NseuilRef / ${LOAD_CORR[$ih]}" | bc)
		case $methode in
		 2|5)
			if [[ x${PIDC[$ih]} = xz ]] ; then 
				echo 'Probleme: methode inapplicable, absence de pid de controle'
			fi
		 	;;
		esac
	fi
done < $JobCtrlDir/SGE_JobData

if [[ ${NHOSTS} -ne ${ih} ]] ; then echo 'Probleme de lecture du pe_hostfile'; fi

# Si la suspension est declenchee par une surcharge, elle peut etre conditionnelle.
# La suspension est immediate si le job est en queue "long" sur tous les noeuds.
# La suspension est immediate si le job est en queue "prio" sur tous les noeuds.
# Sinon, elle est conditionnelle. 
arretConditionnel=non
echo ${PrioEff[*]} | grep B 2>/dev/null 1>&2
if [ $? -eq 0 ] ; then 
	arretConditionnel=oui ; 
	delai=$(echo | awk '{srand(); print 7+10*rand()}' | tr , .)
fi

# Politique severe en raison du manque d'infos necessaires pour la gestion de la subordination.
if [[ $SCORRECT = n ]] ; then arretConditionnel=non ; fi
# Politique simplifiee en cas de procedure exceptionnelle
if [[ x$sitexc = xoui ]] ; then arretConditionnel=non ; fi


# SUBORDINATION: ne pas suspendre un job "big" pour cause de surcharge
#           tant que des jobs "long" sont running sur les noeuds subordonnes.
#     Exception: si des jobs "prio" sont presents, alors suspension immediate.
if [[ ${arretConditionnel} = oui ]] ; then
	QUEUESUB='long_*.q'
	while ( true ) ; do 
		etat=$(etat_affiche_par_SGE)
		echo ${etat} | grep T  1>/dev/null 2>&1
		if [ $? = 0 ] ; then
			SUBOR2=""
			for (( i=1 ; i<=${NHOSTS} ; i++ )) ; do
 				if [[ ${PrioEff[$i]} = P ]] ; then 
# ATTENTION: politique qui empeche la suspension de la queue prio pour surcharge. 
					continue
				elif [[ ${PrioEff[$i]} = B ]] ; then
					read los blabla < <(${CONNEXION[$i]} cat /proc/loadavg)
					marge=$(echo "scale=2; ${Nseuil[$i]} - $los " | bc )
					echo $marge |  grep '-' 2>/dev/null 1>&2
					if [ $? -eq 0 ]; then 
						jup=$($SGE_bin/qstat -q ${QueuePrio}*@${hote[$i]} -f | eval awk \'/${hote[$i]%%.*}/ {print \$3}\' | cut -d/ -f2 )
						jub=$($SGE_bin/qstat -q ${QueueMixte}*@${hote[$i]} -f | eval awk \'/${hote[$i]%%.*}/ {print \$3}\' | cut -d/ -f2 )
						jupb=$(( $jup + $jub ))
# Politique basee sur le nombre de slots utilises, independamment de l'etat des jobs.
						if [[ $jupb -gt $coresPerNode ]] ; then 
							SUBOR2=arret
							delaiSuppl=0
							break
						else 
							tsbd2=$($SGE_bin/qstat -u '*' -q ${QUEUESUB}@${hote[$i]} -s r |wc -l)
# Politique basee l'etat des jobs, independamment du nombre de slots utilises.
							if [[ $tsbd2 -le 2 ]] ; then SUBOR2=arret ; fi
						fi
					fi
				elif [[ ${PrioEff[$i]} = L ]] ; then
					read los blabla < <(${CONNEXION[$i]} cat /proc/loadavg)
					marge=$(echo "scale=2; ${Nseuil[$i]} - $los " | bc )
					echo $marge |  grep '-' 2>/dev/null 1>&2
					if [ $? -eq 0 ]; then SUBOR2=arret ; delaiSuppl=0 ; break ; fi
				else
					echo 'Probleme: cas non prevu'
					SUBOR2=arret
					delaiSuppl=0
					break
				fi
			done
			if [[ x$SUBOR2 = xarret ]] ; then
				if  [[ -f $Ucadenas ]] ; then 
					rm  $Ucadenas 
					if  [[ $delaiSuppl -eq 0 ]] ; then 
						echo 'Suspension du job declenchee par une surcharge, job non prioritaire.'
						break
					fi
					sleep  $delaiSuppl
					continue
				else
					echo 'Suspension du job declenchee par une surcharge'
					break
				fi
			else
				if  [ ! -f $Ucadenas ] ; then 
					touch $Ucadenas
					delaiSuppl=45
				fi
				echo 'Suspension demandee, mais pas encore effective.'
				sleep ${delai}            # TEMPORISATION A AJUSTER
				continue 
			fi
		elif [[ x${etat} = xr ]] ; then
			if  [[ -f $Ucadenas ]] ; then rm $Ucadenas ; fi
			echo 'Job non suspendu car prioritaire sur des jobs en queue long_*'
			echo "bye bye, le " $(date)
			exit 0
		elif [[ x${etat} = xS ]] ; then
			if  [[ -f $Ucadenas ]] ; then rm  $Ucadenas ; fi
			echo 'Suspension de l une des queue_instances utilisees par ce job'
			break
		elif [[ x${etat} = xs ]] ; then
			if  [[ -f $Ucadenas ]] ; then rm  $Ucadenas ; fi
			echo "Suspension a la demande de l'utilisateur" 
			break
		elif [[ x${etat} = xSs ]] ; then
			echo "Suspension queue ou job , mais signal anormal" 
			break
		else		
			echo 'Situation non prevue. Suspension du job. Etat=' $etat 
			break
		fi
	done
fi			

# A partir d ici il s agit de reellement envoyer un signal de suspension

# Envoi du signal adapte au type de MPI utilise par le job
case $methode in
  1)                 
# signal envoye au script soumis a SGE
	kill -STOP -- -$job_pid
	;;
  2)                 
# signal envoye au processus parent sur chaque noeud
	for (( i=1; i<=${NHOSTS}; i++ )) ; do 
		eval "${CONNEXION[$i]} kill -STOP -- -${PIDC[$i]} &"
	done
	;;
  3)                 
# signal envoye par le truchement de l anneau de demons MPD
    MPI_TYPE=$MOT1
	export I_MPI_ROOT=$MOT2
	export I_MPI_MPD_TMPDIR=$MOT3
	export I_MPI_JOB_CONTEXT=$MOT4
	ACTION=STOP     # syntaxe tres souple, qui admet: -STOP SIGSTOP -SIGSTOP; TSTP convient aussi
# ATTENTION: on identifie le jobid par simplement "1" car MatStu cree un anneau de demons mpd par job.
	${I_MPI_ROOT}/bin/mpdsigjob $ACTION -j 1
	;;
  4)                 
# signal TSTP envoye a mpirun en tant que processus simple
  	eval "kill -TSTP -- ${PIDC[1]} &"
	;;
  5)                 
# signal STOP envoye a chaque process group leader
	for (( i=1; i<=${NHOSTS}; i++ )) ; do 
		eval "${CONNEXION[$i]} kill -STOP -- -${PIDC[$i]} &"
	done
	;;
  6|7)                 
# signal TSTP envoye au process pmi_proxy du noeud de lancement
	eval "kill -TSTP -- -${PIDC[1]} &"
	;;
esac

# Ouverture du cadenas
if  [[ x$Scadenas != x ]] ; then 
	if  [[ -f $Scadenas ]] ; then rm $Scadenas 2>/dev/null ; fi
	fi

etat_affiche_par_SGE | grep S 1>/dev/null 2>&1
if [  $? = 0 ] ; then
		echo 'Queue suspendue par SGE'
	else
		echo "Suspension du job $job_id, par SGE (cas de surcharge) ou par l utilisateur."
	fi
echo "bye bye, le " $(date)

} > ${fichier_sortie}

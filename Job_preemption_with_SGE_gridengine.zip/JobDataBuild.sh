#!/bin/bash


# Ce script a deux objectifs: 
# 1) construire un fichier contenant autant de lignes qu'il y a 
#    de hotes d'execution, et contenant pour chaque ligne:
# nom_du_hote nbre_de_slots_sur_ce_hote PGID_des_process_de_calcul Commande_de_connexion_entre_noeuds
# 2) verifier que la commande mpi a bien ete lancee avec un "machinelist" qui 
# respecte l'allocation de processeurs faite par SGE.

# Ce script doit etre execute sur le hote d'ou a ete lance le job mpi 
#   et par le proprietaire du job.
# Il rassemble les infos sur les processus qui sont reellement actifs. 
# La methode utilisee est specifique a chaque implementation de mpi.

# WARNING: En raison de la syntaxe "< <(...)" ce script necessite une version recente de bash.

#********* CUSTOMISATION: suivant les machines, ajuster les lignes suivantes...          **********
# en principe ce script est sourced, donc il herite de l'environnement du script qui l'appelle.
Protocole_Connexion=ssh        # commande pour se connecter aux autres noeuds de calcul: rsh ou ssh
#Protocole_Connexion=rsh        # ATTENTION, tintin est mal configure pour rsh: certains nds demandent un mdp.
#JobCtrlDir=$PWD 
JobCtrlDir=$TMPDIR 
#*********      .... jusqu'ici.                   **************************************************

NVMPI=non    
# Cas d'une NOUVELLE VERSION de MPI : pour aider � la mise au point, utiliser l'option suivante:
NVMPI=OUI       # commenter cette ligne pour supprimer l'affichage des infos.

function correction_de_charge {
	case ${1} in
	     03|04|17|18|19)         # Opteron Interlagos 6220 sous CentOS 5.7
#		echo 0.917               # ancienne valeur jusqu'au 11/02/2014
		echo 0.99                    # nouvelle valeur   au 27/05/2014
		;;
#	     01|02|11|12|13|14|15|16)
#		echo 1          # = Reference : Opteron Magny-Cours 6136 sous CentOS 5.5
#		;;
#	     05|06)
#		echo 1          # Opteron Abu-Dhabi 6328 sous CentOS 5.7
#		;;
	     *)
		echo 1          # Futurs noeuds qui ne sont presents qu'en reve, ou autres machines
		;;
	esac

# 2014 / 02 /11 : je supprime cette correction de charge suite a des tests de Laurent.
# Modification faite aussi via 'qconf -me host_j' pour les machines 03,04,17,18,19.
#	echo 1
# 2014 / 05 /27 : je retablis la correction, mais plus faible.
}

function job_incontrolable {
	echo 'Job non controlable par SGE. Suspension => arret definitif'
	kill -TERM -- $job_pid
	exit
}


echo
echo "hello from JobDataBuild.sh le" $(date) " depuis " $(hostname)
echo
moi=$(whoami)
ici=$(hostname); ici_short=${ici%%.*}; ici_short=${ici_short/*tintin/tintin}
INFOS_SIG_MPI=""
SCORRECT=o
MDQ=N

# Suivant les gestionnaires de batch il faudra adapter cette ligne
fich_source=$PE_HOSTFILE

if [[ x$PE_HOSTFILE = x ]]; then 
# Job sans parallel environnement PE_HOSTFILE
	methode=1   # signaux ordinaires STOP et CONT envoyes a $job_pid
	INFOS_SIG_MPI="Ceci n'est pas un job MPI"
	h=${ici%%.*} ; hote=${ici_short}; h=${h#*tintin}
	Qcat=${QUEUE%_*} 
	case ${Qcat} in
	  $QueuePrio)
	  	PrioEff=P
		;;
	  $QueueMixte) 
		PrioEff=B
		;;
	  *)
		PrioEff=L
		;;
	esac
	PIDC=$job_pid
# Facteur correctif pour la mesure de la charge, suivant le modele de machine
	LOAD_CORR=$(correction_de_charge ${h})
	case $NSLOTS in
	  1)
		commentaire='Job sequentiel'
		;;
	  *)
		commentaire='Job multiprocs mais sans environnement parallele, peut-etre OpenMP?'
		;;
	esac
	echo $methode >$JobCtrlDir/SGE_JobData
	echo $SCORRECT $MDQ $commentaire >>$JobCtrlDir/SGE_JobData
	echo $INFOS_SIG_MPI >>$JobCtrlDir/SGE_JobData
	echo ${hote} ${NSLOTS} $PrioEff $LOAD_CORR ${PIDC} ' ' >>$JobCtrlDir/SGE_JobData
	if [[ $NHOSTS -ne 1 ]] ; then 
		echo 'Job utilisant plusieurs noeuds mais sans environnement parallele.'
		job_incontrolable 
		exit
	fi
	return 	  
fi

# A partir d'ici il s'agit d'un job avec un environnement parallele.

# Recherche des donnees de base.
# PIDC[$i] est "le chef" des processus sur le noeud i, celui a qui on envoie les signaux.

declare -a hote nslots PrioEff LOAD_CORR PIDC CONNEXION
i=0
while read -r line; do
 	h=`echo $line | cut -d" " -f1 ` ; h=${h%%.*}
	hoteC=${h/*tintin/tintin}; h=${h#*tintin}   # hote[$i] contient le nom court de la machine
    nslotsC=`echo $line | cut -d" " -f2`
	Qcat=`echo $line | cut -d" " -f3` ; Qcat=${Qcat%_*} 
	testnh=oui
	for (( ir=1; ir<=${i}; ir++ )); do
		if [[ ${hote[${ir}]} = ${hoteC} ]] ; then 
			SCORRECT=n 
			testnh=non
			MDQ=O
			nslots[${ir}]=$(( ${nslots[${ir}]} + ${nslotsC} ))
			case ${PrioEff[${ir}]} in
			  P)
				case ${Qcat} in
				  ${QueueMixte})
				  	PrioEff[${ir}]=B
					;;
				  *) 
					PrioEff[${ir}]=L
					;;
				esac
				;;
			  B)
				case ${Qcat} in
				  ${QueuePrio}) 
					PrioEff[${ir}]=B
					;;
				  *) 
					PrioEff[${ir}]=L
					;;
				esac
				;;
			esac
			break 1
		fi
	done
	if [[ ${testnh} = non ]] ; then continue ; fi
    i=`expr $i + 1`
	hote[$i]=${hoteC}
	nslots[$i]=${nslotsC}
	case ${Qcat} in
	  ${QueuePrio})
	  	PrioEff[$i]=P
		;;
	  ${QueueMixte}) 
		PrioEff[$i]=B
		;;
	  *)
		PrioEff[$i]=L
		;;
	esac
	PIDC[$i]=z          # initialisation necessaire a autre chose qu'un blanc et un chiffre
#  Facteur correctif pour la mesure de la charge, suivant le modele de machine
	LOAD_CORR[$i]=$(correction_de_charge ${h})
	case ${hote[$i]%%.*} in
	  $ici_short) 
		CONNEXION[$i]=' '
		;; 
	  *) 
		CONNEXION[$i]="${Protocole_Connexion} -o BatchMode=yes -l $moi ${hote[$i]} "
		;;
	esac
done < $fich_source
if [[ ${NHOSTS} -ne ${i} ]] ; then echo 'Probleme de lecture du pe_hostfile' $NHOSTS $i; fi


# Test des connexions inter-noeuds par ssh.
# Attention, ce test ne peut pas etre inclus dans la boucle de lecture du PE_HOSTFILE
# pour des questions de redirection de l'entree et la sortie standard.
for ((i=2;i<=$NHOSTS;i++)); do
		testcon=0
		${CONNEXION[$i]} /bin/true 2>/dev/null 
		testcon=$?
		if [[ x$testcon == x255 ]] ; then job_incontrolable ; exit;  fi
done


## Est-ce un job mono-noeud ou sur plusieurs noeuds?
if [[ $NHOSTS -eq 1 ]] ; then 
	echo "Job sur un seul noeud"
else
	echo "Job sur plusieurs noeuds" 
	MDQ=O
	if [[ x${hote[1]%%.*} != x$ici_short ]] ; then 
		echo 'attention bizarrerie: hote[1] != $(hostname)'
		echo '=> il faut peut-etre modifier le script JobDataBuild pour remettre les hotes dans le bon ordre'
	fi
fi

## Recuperation du PID du process de lancement mpi via le pstree qui contient le job_pid

####### debut de la boucle en cas de job MPI
# Recherche de la commande mpi. 
# On suppose que le nom de la commande contient "mpi"
# est-ce un mpirun ou un mpiexec ou mpiexec.hydra?
treepm=$(pstree -Anlc $job_pid | head -1)
# completer la ligne ci-dessous pour les autres versions de MPI
MPI_CMD=`echo $treepm | awk '/mpirun/ {print "mpirun"} /mpiexec\.hydra/ {print "mpiexec.hydra"} /mpiexec/&&!/mpiexec\.hydra/ {print "mpiexec"}'`
# en cas d'echec, recherche plus approfondie:
if [[ x$MPI_CMD = x ]] ; then 
	interm=${treepm%%mpi*}
	# commande juste avant mpiXXX dans le pstree; deux possibilites 
	interm1=${interm%---*}; interm1=${interm1}--- 
	interm2=${interm%-+-*}; interm2=${interm2}-+- 
	echo $interm1 $interm2
	mpi_cmd1=${treepm#$interm1}; mpi_cmd1=${mpi_cmd1%%---*};mpi_cmd1=${mpi_cmd1%%-+-*}
	mpi_cmd2=${treepm#$interm2}; mpi_cmd2=${mpi_cmd2%%---*};mpi_cmd2=${mpi_cmd2%%-+-*}
	echo $mpi_cmd1  $mpi_cmd2
	test1=$(echo $mpi_cmd1 | grep mpi 2>/dev/null)
	if [[ x$test1 != x ]] ; then 
		MPI_CMD=$mpi_cmd1
	else
		test2=$(echo $mpi_cmd2 | grep mpi 2>/dev/null)
		if [[ x$test2 != x ]] ; then 
			MPI_CMD=$mpi_cmd2
		else
			if [[ $NHOSTS -eq 1 ]] ; then 
				echo "Job n'utilisant pas de commande 'mpi*'; il peut s'agir d'un job OpenMP"
			else
				echo "ATTENTION! job sur plusieurs noeuds mais commande 'mpi*' non reconnue; controle du job impossible!"
			fi
			commentaire="Signalisation avec la methode par defaut"
	 		methode=1   # signaux ordinaires STOP, CONT et TERM envoyes a $job_pid
			echo $methode >$JobCtrlDir/SGE_JobData
			echo $SCORRECT $MDQ $commentaire >>$JobCtrlDir/SGE_JobData
			echo $INFOS_SIG_MPI >>$JobCtrlDir/SGE_JobData
			echo $(hostname) ${NSLOTS} ${PrioEff[1]} ${LOAD_CORR[1]} ${job_pid} " " >>$JobCtrlDir/SGE_JobData
			return 	  
		fi
	fi
fi # fin de la recherche approfondie

[ $NVMPI = OUI ] && echo 'MPI_CMD=' $MPI_CMD

# A partir d'ici on connait la commande mpi utilisee

# Recherche du pid de la commande mpi
treepm=$(pstree -Anlpc $job_pid | head -1)
MPICMD_PID=${treepm#*$MPI_CMD(}; MPICMD_PID=${MPICMD_PID%%)*}

[ $NVMPI = OUI ] && echo 'MPICMD_PID=' $MPICMD_PID

# Recherche du detail de la commande mpi: soit la commande contient le chemin, soit 
#   ce chemin est contenu dans le PATH en vigueur au moment du qsub (= variable SGE_O_PATH)
MPI_CMD_C=$(ps h -p $MPICMD_PID -o command)   # ligne de commande complete
MPI_DIR_a=${MPI_CMD_C%$MPI_CMD*} ; MPI_DIR_a=${MPI_DIR_a%/} ; MPI_DIR_a=${MPI_DIR_a##*\ }
MPI_DIR_b=$(PATH=$SGE_O_PATH type -P $MPI_CMD) ; MPI_DIR_b=${MPI_DIR_b%/$MPI_CMD*}
MPI_DIR=${MPI_DIR_a:-$MPI_DIR_b}

MPI_CMD_L=${MPI_DIR}/${MPI_CMD}   # chemin + commande mpirun
MPI_VERSION1=$($MPI_CMD_L -version 2>/dev/null | head -n1)
MPI_VERSION2=$($MPI_CMD_L --version 2>&1 | head -n1 | egrep "mpi|MPI")
MPI_VERSION=${MPI_VERSION1:-$MPI_VERSION2}


[ $NVMPI = OUI ] && echo 'MPI_DIR=' $MPI_DIR 
[ $NVMPI = OUI ] && echo 'MPI_VERSION=' $MPI_VERSION


# Recherche de la liste des processus sur tous les hotes.
# La procedure est a customiser pour tous les PE existants, sur le
#       modele de ce qui est fait pour hpmpi ou Intel MPI 4.0.
# On s'appuie SOIT sur la version de mpirun, SOIT sur le repertoire contenant mpirun.
MPI_TYPE=""
MPI_INFO_CMD=""
case $MPI_VERSION in
	'mpirun: HP MPI 02.03.01.00 [7779] Linux x86-64') 
	    methode=2
	    commentaire="hpmpi utilise par MatStu jusqu a la v5.5"
	    MPI_TYPE=hpmpi
        MPI_INFO_CMD=/opt/hpmpi/bin/mpijob
	    INFOS_SIG_MPI="$MPI_TYPE $MPI_INFO_CMD"
	    ;;
	'Intel(R) MPI Library for Linux Version 4.0 Update 1')  
	    methode=3
	    commentaire="Intel MPI v4.0 utilise par MatStu pour la v6.0"
	    MPI_TYPE=Intel_MPI_v4.0.1
# Chaque job MatStu donne lieu a la creation d'un anneau de demons mpd specifique a ce job. 
# L'anneau mpd a ete lance en mode "console", mais les infos ont ete perdues et il faut les retrouver.
# L'utilisation ulterieure d'une commande de type mpdXXX necessite que l'environnement soit reconstruit
#      a l'identique de ce qu'il etait au lancement de l'anneau.
# Suivant que le job a ete lance par MatStu ou en Standalone, l'environnement n'est pas le meme.
	    MPDTMPDIR=${I_MPI_MPD_TMPDIR:=/tmp} 
	    MatStu_InstallDIR=${MPI_DIR%/bin}
	    I_MPI_ROOT=${I_MPI_ROOT:-${MatStu_InstallDIR}}
	    MPI_SOCKET=$(ls ${MPDTMPDIR}/mpd2.console_${moi}_*_${MPICMD_PID})
	    CONSOLE_SUFF=${MPI_SOCKET#*mpd2.console_${moi}_}
	    CONSOLE_SUFF=${I_MPI_JOB_CONTEXT:=$CONSOLE_SUFF}
	    export I_MPI_ROOT I_MPI_MPD_TMPDIR I_MPI_JOB_CONTEXT
	    ${I_MPI_ROOT}/bin/mpdlistjobs > $JobCtrlDir/SGE_mpdJobInfo
# Les 7 lignes qui suivent ne sont utiles qu'en cas de probleme.
    	MPDJOBID=`grep -m1 jobid $JobCtrlDir/SGE_mpdJobInfo`
	    MPDJOBID=${MPDJOBID##*\ }
	    if [[ x$MPDJOBID = x ]] ; then 
			methode=1
			commentaire=`echo "Probleme: impossible de determiner l'id du job par mpdlistjobs $TMP $TMPDIR $MPDTMPDIR ${MPDTMPDIR}"`
	    fi
	    ;;
	'mpirun (Open MPI) 1.4.3')
	    methode=4
		MPI_TYPE=OpenMPI
   		commentaire='Open MPI v1.4.3 dans /usr/local/openmpi-gnu*'
		MPI_INFO_CMD=${MPI_DIR}/ompi-ps
	    ;;
    'Intel(R) MPI Library for Linux* OS, Version 4.0 Update 3 Build 20110824')
		methode=5	
	    commentaire="Intel MPI v4.0 avec hydra utilise par MatStu a partir de la v6.1"
	    MPI_TYPE='Intel_MPI_v4.0.3_hydra'
	    MatStu_InstallDIR=${MPI_DIR%/bin}
	    I_MPI_ROOT=${I_MPI_ROOT:-${MatStu_InstallDIR}}
			treepm=$(pstree -Anlpc $job_pid | grep pmi_proxy); trash=${treepm#*pmi_proxy(}; 
			PMI_PROXY_PID=${trash%%)*}; # echo $PMI_PROXY_PID
			trash=$(ps ww $PMI_PROXY_PID | grep control-port); trash=${trash#*control-port\ }; 
		CONTROL_PORT=${trash%%\ *}; # echo $CONTROL_PORT
	    INFOS_SIG_MPI="${MPI_TYPE} ${I_MPI_ROOT} ${CONTROL_PORT} ${MPICMD_PID}"
		;; 
    'Intel(R) MPI Library for Linux* OS, Version 4.1.0 Build 20130116')
		methode=6
	    commentaire="Intel MPI v4.1.0 avec hydra utilise par MatStu a partir de la v7.0"
	    MPI_TYPE='Intel_MPI_v4.1.0_hydra'
	    MatStu_InstallDIR=${MPI_DIR%/bin}
	    I_MPI_ROOT=${I_MPI_ROOT:-${MatStu_InstallDIR}}
			treepm=$(pstree -Anlpc $job_pid | grep pmi_proxy); trash=${treepm#*pmi_proxy(}; 
			PMI_PROXY_PID=${trash%%)*}; # echo $PMI_PROXY_PID
			trash=$(ps ww $PMI_PROXY_PID | grep control-port); trash=${trash#*control-port\ }; 
		CONTROL_PORT=${trash%%\ *}; # echo $CONTROL_PORT
	    INFOS_SIG_MPI="${MPI_TYPE} ${I_MPI_ROOT} ${CONTROL_PORT} ${MPICMD_PID}"
		;; 
    'Intel(R) MPI Library for Linux* OS, Version 4.1 Update 3 Build 20140124')
		methode=7
	    commentaire="Intel MPI v4.1.0 avec hydra utilise par MatStu a partir de la v8.0"
	    MPI_TYPE='Intel_MPI_v4.1_update3_hydra'
	    MatStu_InstallDIR=${MPI_DIR%/bin}
	    I_MPI_ROOT=${I_MPI_ROOT:-${MatStu_InstallDIR}}
			treepm=$(pstree -Anlpc $job_pid | grep pmi_proxy); trash=${treepm#*pmi_proxy(}; 
			PMI_PROXY_PID=${trash%%)*}; # echo $PMI_PROXY_PID
			trash=$(ps ww $PMI_PROXY_PID | grep control-port); trash=${trash#*control-port\ }; 
		CONTROL_PORT=${trash%%\ *}; # echo $CONTROL_PORT
	    INFOS_SIG_MPI="${MPI_TYPE} ${I_MPI_ROOT} ${CONTROL_PORT} ${MPICMD_PID}"
		;; 
	'mpirun (Open MPI) 1.8.1')
	    methode=4
		MPI_TYPE=OpenMPI
   		commentaire='Open MPI v1.8.1 dans /usr/local/openmpi-482-gnu'
		MPI_INFO_CMD=${MPI_DIR}/ompi-ps
	    ;;
	*)
# Helas nombreux sont les mpirun qui ne disent pas leur version => identification par MPI_DIR.
		case $MPI_DIR in
			/usr/local/mpich-gnu/bin)         # cf /usr/local/mpich-1.2.7p1
# a completer 
				methode=1
				MPI_VERSION=mpich
	    		;;
			/usr/local/lam-gnu/bin)            # cf /usr/local/lam-7.1.4
# a completer
				methode=1
				MPI_VERSION=lam
	    		;;
			/usr/local/mpich2-gnu/bin)          # cf /usr/local/mpich2-1.3.2p1
# a completer
				methode=3   # ou autre, si usage de "hydra".
				MPI_VERSION='mpich2'
				MPI_SIG_CMD=${MPI_DIR}/mpdsigjob
	    		;;
			*)
				methode=1
				MPI_VERSION=inconnue
	    		;;
		esac
esac

[ $NVMPI = OUI ] && echo 'methode=' $methode

# Recherche du pid du processus de controle sur chaque noeud.
case $methode in
	2)    
# cas de /opt/hpmpi (et peut-etre aussi openmpi-gnu)
	    declare -a procliste
        procliste=($($MPI_INFO_CMD -j $MPICMD_PID |  awk '{print $2 ":" $3}'))
	    for (( i=1; i<=$NHOSTS; i++ )) ; do 
		   	proccalc=$(for j in ${procliste[@]}; do echo $j; done  | grep -m1 ${hote[$i]%%.*} | cut -d":" -f2)
		   	procparent=$(${CONNEXION[$i]} ps h -p ${proccalc} -o pgid)
			if [[ x${procparent} = x ]] ; then 
				methode=1
				commentaire="Probleme sur hote ${hote[$i]}: processus ${proccalc[$i]} sans parent"
				PIDC[1]=${job_pid}
				break
			else
				PIDC[$i]=${procparent}
			fi
	    done
	    ;;
	3)  
# cas de Intel MPI 4.0 avec utilisation d'un anneau de demons mpd
	    INFOS_SIG_MPI="$MPI_TYPE ${I_MPI_ROOT} ${I_MPI_MPD_TMPDIR} ${I_MPI_JOB_CONTEXT} ${MPICMD_PID}"
	    ;;
	4)   
# cas de Open MPI v1.4.3 dans openmpi-gnu
	     # attention pour que ca marche il faut que mca_job_control=1
	    INFOS_SIG_MPI="$MPICMD_PID $MPI_INFO_CMD"
		PIDC[1]=${MPICMD_PID}
	    ;;
	5)    
# cas de Intel MPI 4.0.3 avec Hydra
		PIDC[1]=${job_pid}
	    for (( i=2; i<=$NHOSTS; i++ )) ; do 
#			PIDC[$i]=$(${CONNEXION[$i]} 'ps ww -C pmi_proxy' | grep ${CONTROL_PORT} | cut -d" " -f1) 
			read procctrl blabla < <(${CONNEXION[$i]} ps ww -C pmi_proxy | grep ${CONTROL_PORT} ) 
			if [[ x${procctrl} = x ]] ; then 
				methode=1
				commentaire="Probleme sur hote ${hote[$i]}: processus ${procctrl} absent"
				break
			else
				PIDC[$i]=${procctrl}
			fi
	    done
	    ;;
	6)    
# cas de Intel MPI 4.1.0 avec Hydra 
# Sur tintin, il faut activer l'option '-genv I_MPI_JOB_SIGNAL_PROPAGATION 1' dans ~/.mpiexec.conf
# Sur tintin, il faut activer l'option '-genv I_MPI_HYDRA_BOOTSTRAP sge' dans ~/.mpiexec.conf
# Puis on peut utiliser les signaux TSTP et CONT sur le process pmi_proxy .
#   NB: les signaux peuvent etre envoyes sur l'un ou l'autre des noeuds, il y a propagation.
	    for (( i=1; i<=$NHOSTS; i++ )) ; do 
			read procctrl blabla < <(${CONNEXION[$i]} ps ww -C pmi_proxy | grep ${CONTROL_PORT} ) 
			if [[ x${procctrl} = x ]] ; then 
				methode=1
				commentaire="Probleme sur hote ${hote[$i]}: processus ${procctrl} absent"
				break
			else
				PIDC[$i]=${procctrl}
			fi
	    done
	    ;;
	7)    
# cas de Intel MPI 4.1 update 3 avec Hydra
# Sur tintin, il faut activer l'option '-genv I_MPI_JOB_SIGNAL_PROPAGATION 1' dans ~/.mpiexec.conf
# Sur tintin, il faut activer l'option '-genv I_MPI_HYDRA_BOOTSTRAP sge' dans ~/.mpiexec.conf
# Puis on peut utiliser les signaux TSTP et CONT sur le process pmi_proxy .
#   NB: les signaux peuvent etre envoyes sur l'un ou l'autre des noeuds, il y a propagation.
	    for (( i=1; i<=$NHOSTS; i++ )) ; do 
			read procctrl blabla < <(${CONNEXION[$i]} ps ww -C pmi_proxy | grep ${CONTROL_PORT} ) 
			if [[ x${procctrl} = x ]] ; then 
				methode=1
				commentaire="Probleme sur hote ${hote[$i]}: processus ${procctrl} absent"
				break
			else
				PIDC[$i]=${procctrl}
			fi
	    done
	    ;;
	*)  
# environnement parallele que ce script ne sait pas traiter
	    methode=1
		if [[ x$MPI_VERSION -ne x ]]; then commentaire="Version MPI= $MPI_VERSION. $commentaire"; fi
	    nslots[1]=$NSLOTS
	    PIDC[1]=${job_pid}
	    ;;
esac

# ECRITURE des infos disponibles dans un fichier SGE_JobData
echo $methode >$JobCtrlDir/SGE_JobData
echo $SCORRECT $MDQ $commentaire >>$JobCtrlDir/SGE_JobData
echo $INFOS_SIG_MPI >>$JobCtrlDir/SGE_JobData
for (( i=1; i<=${NHOSTS}; i++ )) ; do 
	echo ${hote[$i]} ${nslots[$i]} ${PrioEff[$i]} ${LOAD_CORR[$i]} ${PIDC[$i]} ${CONNEXION[$i]} 
done >>$JobCtrlDir/SGE_JobData
echo "bye from JobDataBuild"
echo

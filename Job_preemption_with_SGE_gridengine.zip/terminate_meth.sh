#!/bin/bash
# Script ecrit par Philippe ZELLER le 13 janvier 2012.
# Il va de pair avec le "JobDataBuild.sh"

# WARNING: En raison de la syntaxe "< <(...)" ce script necessite une version recente de bash.

ici=$(hostname); ici_short=${ici%%.*} ; ici_short=${ici_short/*tintin/tintin}

#********* CUSTOMISATION: suivant les machines, ajuster les lignes suivantes...        *************
SGE_bin=$SGE_ROOT/bin/lx26-amd64
JobCtrlDir=$TMPDIR
QueuePrio=prio  # tintin: mot-cle identifiant la queue pour laquelle "resume" est immediat
QueueMixte=big  # tintin: mots-cles identifiant la queue parfois subordonnee, parfois prioritaire.
JobDataBuild=/home/sgeadmin/utilitaires/JobDataBuild.sh
duree=0.1           # intervalle, en secondes, entre l'envoi de deux signaux a un meme processus.

case ${ici_short} in
   tintin*)
coresPerNode=32
NseuilRef=32.9     # pour tintin, machine de reference: Opteron 6136 sous CentOS 5.5
NseuilRef_special=32.4
JobDataBuild=/home/sgeadmin/utilitaires/JobDataBuild.sh    # sur tintin
duree=1   
     ;;
esac
#*********       .... jusqu ici.         ***********************************************************
NseuilRef_special=${NseuilRef_special:-NseuilRef}


fichier_sortie=./SGE.${HOSTNAME%.*}.$JOB_ID.$(whoami).terminate.$(date +%s)
# redirection de la sortie standard pour le shell
{

echo
ici=$(hostname); ici_short=${ici%%.*}; ici_short=${ici_short/*tintin/tintin}
echo "hello from Terminator at " ${ici} "    on " $(date)
echo
job_pid=$1           
duree_minimale=$2    
moi=$(whoami)
echo '$(hostname)='$ici
echo '$(whoami)='$moi
echo "JOB_ID =" $JOB_ID
echo "job_pid=" $job_pid
echo "TMPDIR=" $TMPDIR
echo "PWD=" $PWD
echo "PE_HOSTFILE=" $PE_HOSTFILE
echo "PE=" $PE
echo "NHOSTS=" $NHOSTS
echo "NSLOTS=" $NSLOTS
echo "NQUEUES=" $NQUEUES

# Sommes-nous bien sur le noeud de lancement du job?
# si ce n'est pas le cas, ne rien faire et sortir
ndl=${PE_HOSTFILE##*/sge/} ; ndl=${ndl%%/*} 
# echo $ndl
if [[ $ndl != $ici_short &&  xxx$ndl != xxx ]] ; then 
	echo "Je ne suis pas le noeud de lancement donc je ne fais rien"
	exit
fi

echo "Contenu du pe_hostfile :"
cat $PE_HOSTFILE
echo


# Recherche des donnees de controle des processus.
if [ -f $JobCtrlDir/SGE_JobData ] ; then 
# 	Cas d'un job SGE qui contient plusieurs commandes mpirun qui s'enchainent. 
#   	Il faut tester si les donnees de controle sont bien celles du processus mpirun actuel.
	nf1=$JobCtrlDir/SGE_JobData
	treepm=$(pstree -Anlcp $job_pid | head -1)
	CURRENT_PS=${treepm##*(}; CURRENT_PS=${CURRENT_PS%)}
	if [[ x$CURRENT_PS = x ]] ; then 
		echo 'Absence de processus!'
		sleep 10
		treepm=$(pstree -Anlcp $job_pid | head -1)
		CURRENT_PS=${treepm##*(}; CURRENT_PS=${CURRENT_PS%)}
	fi
	echo $CURRENT_PS	
	nf2=/proc/${CURRENT_PS}
	nf3=$(ls -t $nf1 $nf2 2>/dev/null | head -n1)
	if [[ $nf3 != $nf1 ]] ; then
		rm $JobCtrlDir/SGE_JobData
		. $JobDataBuild
	fi 
# test sur la version du script
	nf2=${JobDataBuild}
	nf3=$(ls -t $nf1 $nf2 2>/dev/null | head -n1)
	if [[ $nf3 != $nf1 ]] ; then
		rm $JobCtrlDir/SGE_JobData
		. $JobDataBuild
	fi 
  else
	. $JobDataBuild 
fi

# Lecture du fichier SGE_JobData
il=0     # indice de ligne du fichier SGE_JobData
ih=0
while read line; do
	il=`expr $il + 1`
	if [[ $il -eq 1 ]] ; then
		read methode < <(echo $line)
	elif [[ $il -eq 2 ]] ; then
		read SCORRECT MDQ commentaire < <(echo $line)
#		commentaire=$line
	elif [[ $il -eq 3 ]] ; then
#		read  MPI_TYPE MPI_SIG_CMD MPI_SOCKET MPDJOBID MPICMD_PID < <(echo $line)
		read  MOT1     MOT2        MOT3       MOT4     MOT5        < <(echo $line)
	else
		ih=`expr $ih + 1`
		read hote[$ih] nslots[$ih] PrioEff[$ih] LOAD_CORR[$ih] PIDC[$ih] CONNEXION[$ih] < <(echo $line)
		case $methode in
		 2|5)
			if [[ x${PIDC[$ih]} = xz ]] ; then 
				echo 'Probleme: methode inapplicable, absence de pid de controle'
			fi
		 	;;
		esac

	fi
done < $JobCtrlDir/SGE_JobData

if [[ ${NHOSTS} -ne ${ih} ]] ; then echo 'Probleme de lecture du pe_hostfile'; fi

# Cas ou d'autres signaux sont en attente d'etre envoyes au job
# Ces attentes sont associees a des processus qu'il faut laisser se terminer normalement.

cadenas_resu=$JobCtrlDir/SGE_resu_lock.$moi.$JOB_ID.  
# Recherche de cadenas pose par un signal "resume" en attente
for k in $(ls -t $cadenas_resu* 2>/dev/null) ; do Rcadenas=$k; break; done
Scadenas=$(echo $Rcadenas | sed -e s/resu/susp/) 	
Hcadenas=$(echo $Rcadenas | sed -e s/resu/harak/)    	
# Si l'envoi d'un signal de suspension est en attente, attendre. Cela ne va pas durer longtemps.
while [[ -e $Scadenas ]] ; do
#	echo "lock $Scadenas present"
	sleep 1
done
# Si le job etait en attente d'une relance, il faut le relancer avant de le tuer
if  [[ -e $Rcadenas ]] ; then
	echo "RELANCE preliminaire du job"
	case $methode in
	  1)
		kill -CONT -- -$job_pid
		;;
	  2)
		for (( i=1; i<=${NHOSTS}; i++ )) ; do 
			eval "${CONNEXION[$i]} kill -CONT -- -${PIDC[$i]} &"
		done
		;;
	  3)
	        MPI_TYPE=$MOT1
	        MPI_TYPE=$MOT1
		export I_MPI_ROOT=$MOT2
		export I_MPI_MPD_TMPDIR=$MOT3
		export I_MPI_JOB_CONTEXT=$MOT4
		MPICMD_PID=$MOT5

		ACTION=CONT     # syntaxe tres souple, qui admet: -STOP SIGSTOP -SIGSTOP; TSTP convient aussi
		${I_MPI_ROOT}/bin/mpdsigjob $ACTION -j 1
		;;
	  4)   # cas Open MPI: m�me pas besoin de relancer
		/bin/true
		;;
  	  5|6|7)  # signal CONT envoye a chaque process group leader
		for (( i=1; i<=${NHOSTS}; i++ )) ; do 
		eval "${CONNEXION[$i]} kill -CONT -- -${PIDC[$i]} &"
		done
		;;
	esac
rm $Rcadenas     
fi

# Le signal TERM ne parviendra au processus que s'il est "R running" ou "S sleeping" mais pas "T suspendu".
# Par precaution, on envoie donc un signal CONT prealable. 
# Genre: je te reveille pour que tu voies que je t'explose; l'informatique est une science immorale.
echo "ARRET du job"
case $methode in
   1)
	kill -CONT -- -$job_pid
	sleep $duree
	kill -TERM -- -$job_pid
	;;
   2)
	for (( i=1; i<=${NHOSTS}; i++ )) ; do 
		eval "${CONNEXION[$i]} kill -CONT -- -${PIDC[$i]} &"
	done
		sleep $duree
	for (( i=1; i<=${NHOSTS}; i++ )) ; do 
		eval "${CONNEXION[$i]} kill -TERM -- -${PIDC[$i]} &"
	done
	;;
   3)
    MPI_TYPE=$MOT1
	export I_MPI_ROOT=$MOT2
	export I_MPI_MPD_TMPDIR=$MOT3
	export I_MPI_JOB_CONTEXT=$MOT4
	MPICMD_PID=$MOT5
	ACTION=CONT     # syntaxe tres souple, qui admet: -STOP SIGSTOP -SIGSTOP; TSTP convient aussi
# ATTENTION: on identifie le jobid par simplement "1" car MatStu cree un anneau de demons mpd par job.
	${I_MPI_ROOT}/bin/mpdsigjob $ACTION -j 1
	sleep $duree
	${I_MPI_ROOT}/bin/mpdkilljob 1
	${I_MPI_ROOT}/bin/mpdallexit
	sleep $duree
	kill -TERM -- -$job_pid
	sleep 1
# En principe la ligne qui suit n'est pas necessaire.
#	rm /tmp/sge_hostfile_${MPICMD_PID} /tmp/sge_machinefile_${MPICMD_PID}
	;;
   4)   # OpenMPI: le processus maitre ne dort jamais, mais faut prendre son temps.
	sleep $duree
  	kill -TERM -- ${PIDC[1]}
	;;
   5|6|7)   # signaux CONT puis TERM envoyes a chaque process group leader
	for (( i=1; i<=${NHOSTS}; i++ )) ; do 
		eval "${CONNEXION[$i]} kill -CONT -- -${PIDC[$i]} &"
	done
	sleep $duree
	for (( i=1; i<=${NHOSTS}; i++ )) ; do 
		eval "${CONNEXION[$i]} kill -TERM -- -${PIDC[$i]} &"
	done
	;;
esac

sleep 1
# Nettoyage de vieux processus d'envoi de signaux qui seraient toujours actifs; on ne sait jamais...
cadenas_resu=$JobCtrlDir/SGE_resu_lock.$moi.$JOB_ID.  
for k in $(ls -t $cadenas_resu* 2>/dev/null) ; do 
	Rcadenas=$k
	Scadenas=$(echo $Rcadenas | sed -e s/resu/susp/) 
	if [[ -e $Scadenas ]] ; then rm $Scadenas ; fi
	if [[ -e $Rcadenas ]] ; then rm $Rcadenas ; fi
done
#Suppression du fichier SGEJobData pour eviter confusion en cas de relance du job.
if [[ -e $JobCtrlDir/SGE_JobData ]] ; then rm $JobCtrlDir/SGE_JobData ; fi
echo "bye bye le " $(date)

} > $fichier_sortie


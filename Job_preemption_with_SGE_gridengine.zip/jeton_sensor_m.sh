#!/bin/bash
#
# (c) 2009 Sun Microsystems, Inc. All rights reserved. Use is subject to license terms.  

# ----------------------------------------
#
# example for a load sensor script
#
# Be careful: Load sensor scripts are started with root permissions.
# In an admin_user system euid=0 and uid=admin_user
#

################################################
# CONFIGURATION : 2 variables
#REPERTOIRE=/tmp/sge      # machine "shared memory"  
#REPERTOIRE=/dev/shm      # machine "shared memory"  : RAM
REPERTOIRE=/scratch/sge   # tintin : accessible a tous les nds du cluster
coresPerNode=32              # tintin 
#################################################

PATH=/bin:/usr/bin


ARCH=`$SGE_ROOT/util/arch`
HOST=`$SGE_ROOT/utilbin/$ARCH/gethostname -name`
SGE_bin=$SGE_ROOT/bin/$ARCH

end=false
while [ $end = false ]; do

   # ---------------------------------------- 
   # wait for an input
   #
   read input
   result=$?
   if [ $result != 0 ]; then
      end=true
      break
   fi
   
   if [ "$input" = "quit" ]; then
      end=true
      break
   fi

   # ---------------------------------------- 
   # send mark for begin of load report
   echo "begin"

   # ---------------------------------------- 
# modifs de PZ
# noms de variables : P=>prio, B=>big, L=>long.
#                    S => used+dispo selon quotas SGE.  U=used selon SGE.
#                     D=>dispo pour un depart sans suspension immediate. 
# jSP, jSB et jSL = slots "U" + slots "D".

	for h in $($SGE_bin/qconf -sel | grep -v tintin.dept ) ; do
		q=prio
		read a a slots a a a < <($SGE_bin/qstat -q ${q}*@${h} -f | grep ${q} | tail -1 )
# JP=total machine, jUP=currently used, jDP=disponibles hors etat S ou d
#    jSP=total sous contrainte.
		jP=$(echo $slots | cut -d"/" -f3) 
		jUP=$(echo $slots | cut -d"/" -f2)
		jDP=$(( $jP - $jUP )) 
# La variable a va contenir un eventuel etat "S" suspended ou "d"=disabled de cette 
#  queue instance, ce qui annule le nb de slots dispo.
# NB : si la queue est en alarme etat "a", je choisis que les slots restent dispo.
		a=${a#a}; a=${a%%\ }
#    d'ou le nombre de slots jSP qui sont effectivement disponibles:
		if [[ x$a != x ]]; then jDEP=0 ; else jDEP=$jDP ; fi  
# NB: choix a faire: jSP affected or not affected par l'etat S ou d de la queue.
#    tenir compte du fait que le script est actualise peu frequemment, 
#    et que de toute facon SGE gere l'etat de la queue avant les quotas.	
		jSP=$(( $jDP + $jUP )) 
#		jSP=$(( $jDEP + $jUP ))	

		q=big
		read a a slots a a a < <($SGE_bin/qstat -q ${q}*@${h} -f | grep ${q} | tail -1 )
		jB=$(echo $slots | cut -d"/" -f3)
		jUB=$(echo $slots | cut -d"/" -f2)
		jDB=$(( $jB - $jUB - $jUP )) ; if [ $jDB -lt 0 ] ; then jDB=0; fi
		a=${a#a}; a=${a%%\ }
		if [[ x$a != x ]]; then jDEB=0 ; else jDEB=$jDB ; fi  
		jSB=$(( $jDB + $jUB ))

		q=long
		read a a slots a a a < <($SGE_bin/qstat -q ${q}*@${h} -f | grep ${q} | tail -1 )
		jL=$(echo $slots | cut -d"/" -f3)
		jUL=$(echo $slots | cut -d"/" -f2)
		jDL=$(( $jL - $jUL - $jUP -$jUB )) ; if [ $jDL -lt 0 ] ; then jDL=0; fi
		a=${a#a}; a=${a%%\ }
		if [[ x$a != x ]]; then jDEL=0 ; else jDEL=$jDL ; fi  
		jSL=$(( $jDL + $jUL )) 

# nb max possible de slots utilises apres lancement d'un job utilisant ce noeud et d'autres.
#   - job a la fois en big et long
		jtBL=$(( $jDB + $jUB + $jUL ))    
#    - job en prio, big et long
		jtPBL=$(( $jDP + $jUP + $jUB + $jUL )) 

# Si sge_qmaster est arrete, certaines variables sont vides.
# Verifier que toutes les variables sont non vides avant d'ecraser le fichier lu par sge_execd
		tot=0
		for v in $jUP $jDEP $jSP $jUB $jDEB $jSB $jUL $jDEL $jSL $jtBL $jtPBL ; do tot=$(( tot + 1 )); done
		if [[ $tot -eq 11 ]] ; then
			echo $jUP $jDEP $jSP $jUB $jDEB $jSB $jUL $jDEL $jSL $jtBL $jtPBL  >$REPERTOIRE/${h}.sgeqdata
		   else
			y=${coresPerNode} ; 
			echo $y 0 $y $y 0 $y $y 0 $y 0 0  >$REPERTOIRE/${h}.sgeqdata
		fi
	done


# fin des modifs de PZ

   # ---------------------------------------- 
   # send mark for end of load report
   echo "end"
done

#!/bin/sh
#
# (c) 2009 Sun Microsystems, Inc. All rights reserved. Use is subject to license terms.  

# ----------------------------------------
#
# example for a load sensor script
#
# Be careful: Load sensor scripts are started with root permissions.
# In an admin_user system euid=0 and uid=admin_user
#

################################################
# CONFIGURATION : juste la ligne suivante
#REPERTOIRE=/tmp/sge      # machine "shared memory"  
#REPERTOIRE=/dev/shm      # machine "shared memory"  : RAM
REPERTOIRE=/scratch/sge   # tintin : accessible a tous les nds du cluster
coresPerNode=32              # tintin 
#################################################

PATH=/bin:/usr/bin


ARCH=`$SGE_ROOT/util/arch`
HOST=`$SGE_ROOT/utilbin/$ARCH/gethostname -name`
SGE_bin=$SGE_ROOT/bin/$ARCH

end=false
while [ $end = false ]; do

   # ---------------------------------------- 
   # wait for an input
   #
   read input
   result=$?
   if [ $result != 0 ]; then
      end=true
      break
   fi
   
   if [ "$input" = "quit" ]; then
      end=true
      break
   fi

   # ---------------------------------------- 
   # send mark for begin of load report
   echo "begin"

   # ---------------------------------------- 

# modifs de PZ
# noms de variables : P=>prio, B=>big, L=>long.
#                    S => used+dispo selon quotas SGE.  U=used selon SGE.
#                     D=>dispo pour un depart sans suspension immediate. 

	if [[ -r $REPERTOIRE/${HOST}.sgeqdata ]] ; then
	read jUP jDP jSP jUB jDB jSB jUL jDL jSL jtBL jtPBL < $REPERTOIRE/${HOST}.sgeqdata
	fi
# Verifier que toutes les variables sont non vides
	tot=0
	for v in $jUP $jDP $jSP $jUB $jDB $jSB $jUL $jDL $jSL $jtBL $jtPBL ; do tot=$(( tot + 1 )); done
	if [[ $tot -ne 11 ]] ; then
		y=${coresPerNode} 
		declare -i jUP=$y jDP=0 jSP=$y jUB=$y jDB=0 jSB=$y jUL=$y jDL=0 jSL=$y jtBL=0 jtPBL=0
	fi

# Complex attributes necessaires pour les quotas (qconf -sqrs): 
#       jeton{prio,big,long}, jetontbl, jetontpbl  
# Complex attributes necessaires pour BD_tintin.sh:
#       jeton{d,u}{prio,big,long}
	echo "$HOST:jetonuprio:$jUP"          # currently used
	echo "$HOST:jetondprio:$jDP"        # disponibles
	echo "$HOST:jetonprio:$jSP"         # total machine
	echo "$HOST:jetonubig:$jUB"           # currently used
	echo "$HOST:jetondbig:$jDB"         # disponibles
	echo "$HOST:jetonbig:$jSB"         # total sous contrainte
	echo "$HOST:jetonulong:$jUL"          # currently used
	echo "$HOST:jetondlong:$jDL"        # disponibles
	echo "$HOST:jetonlong:$jSL"        # total sous contrainte
	echo "$HOST:jetontbl:$jtBL"
	echo "$HOST:jetontpbl:$jtPBL"
# fin des modifs de PZ

   # ---------------------------------------- 
   # send mark for end of load report
   echo "end"
done

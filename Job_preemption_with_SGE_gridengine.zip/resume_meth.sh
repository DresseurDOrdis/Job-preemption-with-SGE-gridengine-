#!/bin/bash
# Script ecrit par Philippe ZELLER le 31 mai 2011.
#   Modifie le 12 janvier 2012 pour prise en compte de Intel MPI v4.0
# Il va de pair avec les scripts "suspend_method.sh" et "JobDataBuild.sh"

# WARNING: En raison de la syntaxe "< <(...)" ce script necessite une version recente de bash.

ici=$(hostname); ici_short=${ici%%.*} ; ici_short=${ici_short/*tintin/tintin}

#********* CUSTOMISATION: suivant les machines, ajuster les lignes suivantes...        *************
SGE_bin=$SGE_ROOT/bin/lx26-amd64
JobCtrlDir=$TMPDIR
QueuePrio=prio  # tintin: mot-cle identifiant la queue pour laquelle "resume" est immediat
QueueMixte=big  # tintin: mots-cles identifiant la queue parfois subordonnee, parfois prioritaire.
JobDataBuild=/home/sgeadmin/utilitaires/JobDataBuild.sh

case ${ici_short} in
   tintin*)
coresPerNode=32
NseuilRef=32.9     # pour tintin, machine de reference: Opteron 6136 sous CentOS 5.5
NseuilRef_special=32.4
JobDataBuild=/home/sgeadmin/utilitaires/JobDataBuild.sh    # sur tintin
     ;;
esac
#*********       .... jusqu ici.         ***********************************************************
NseuilRef_special=${NseuilRef_special:-NseuilRef}


function etat_affiche_par_SGE {
  eval "$SGE_bin/qstat -u $(whoami) -q ${QUEUE}@${ici} | awk '"'$1 ==' $JOB_ID ' {print  $5}'"'"
}

function etat_queue_instance { 
	eqi=$(eval "$SGE_bin/qstat -q ${QUEUE}@${1} -f | awk '/"$1'/ {print $6}'"'")
	eqi=${eqi:-1}
	echo $eqi
}

# Procedure de mise a jour de l affichage running ou suspendu par qstat 
function mise_a_jour_affichage_s {
		etatSGE=$(etat_affiche_par_SGE)
		if [[ x$etatSGE = xr ]] ; then
			touch $Hcadenas
			sleep 1
			eval "$SGE_bin/qmod -sj $JOB_ID"
		fi
}


# redirection de la sortie standard pour ce shell
fichier_sortie=./SGE.${HOSTNAME%.*}.$JOB_ID.resume.$(date +%s)

# 1ere possibilite pour la redirection de la sortie standard: inclut le preambule
# {

# PREAMBULE: signaux pour rire.
# CAS 1: il peut s'agir d'un dummy signal visant juste a mettre a jour l'affichage SGE
### ls -t $JobCtrlDir/SGE_dummy*   1>&2
ls -t $JobCtrlDir/SGE_dummy* 1>/dev/null 2>&1 ; test_dummy=$?
if [ $test_dummy -eq 0 ] ; then
#	echo "ceci est un DUMMY, aucun signal n'est envoye. " 1>&2
	rm $JobCtrlDir/SGE_dummy* 1>&2
	exit 0
fi
# Cas 2: cas d'une subordination: le job n'a pas vraiment ete suspendu
ls -t $JobCtrlDir/SGE_subord* 1>/dev/null 2>&1 ;
if [ $? -eq 0 ] ; then
	echo 'Job en queue big_* prioritaire sur des jobs en queue long_*'
	exit 0
fi

# 2eme possibilite pour la redirection de la sortie standard: exclut le preambule
{

# Ce n'est pas un "signal pour rire". Procedure "normale" et complete.
echo
echo "hello from Resumator at " ${ici} "    on " $(date)
echo
job_pid=$1           
moi=$(whoami)
echo '$(hostname)='$ici
echo '$(whoami)='$moi
echo "JOB_ID =" $JOB_ID
echo "job_pid=" $job_pid
echo "TMPDIR=" $TMPDIR
echo "PWD=" $PWD
echo "PE_HOSTFILE=" $PE_HOSTFILE
echo "PE=" $PE
echo "NHOSTS=" $NHOSTS
echo "NSLOTS=" $NSLOTS
echo "NQUEUES=" $NQUEUES
echo "QUEUE=" $QUEUE
echo "Contenu du pe_hostfile :"
cat $PE_HOSTFILE
echo


cadR=$JobCtrlDir/SGE_resu_lock.$moi.$JOB_ID.
# Valeurs par defaut, necessaires pour les tests d'existence.  
suff=$(date +%s)$(date +%N)
Rcadenas=${cadR}${suff}
Hcadenas=$(echo $Rcadenas | sed -e s/resu/harak/)    	
Dcadenas=$(echo $Rcadenas | sed -e s/resu/dummy/)
Scadenas=$(echo $Rcadenas | sed -e s/resu/susp/) 

# Choix politique: autoriser ou pas l utilisateur a relancer malgre tout...?
# Cette partie reste a mettre au point.
# Avec un seuil de nbSignaux = 1, elle ne fonctionne pas bien.
nbSignaux=$(ls ${cadR}* 2>/dev/null | wc -l)
if [ $nbSignaux -ge 2 ] ; then
		echo 'Ouh la la les signaux se bousculent! je me defile.'
		exit 0
	else
		touch $Rcadenas          
fi

# Recherche des donnees de controle des processus.
if [ -f $JobCtrlDir/SGE_JobData ] ; then 
# 	Cas d'un job SGE qui contient plusieurs commandes mpirun qui s'enchainent. 
#   	Il faut tester si les donnees de controle sont bien celles du processus mpirun actuel.
	nf1=$JobCtrlDir/SGE_JobData
	treepm=$(pstree -Anlcp $job_pid | head -1)
	CURRENT_PS=${treepm##*(}; CURRENT_PS=${CURRENT_PS%)}
	if [[ x$CURRENT_PS = x ]] ; then 
		echo 'Absence de processus!'
		sleep 10
		treepm=$(pstree -Anlcp $job_pid | head -1)
		CURRENT_PS=${treepm##*(}; CURRENT_PS=${CURRENT_PS%)}
		fi
	echo $CURRENT_PS	
	nf2=/proc/${CURRENT_PS}
	nf3=$(ls -dt $nf1 $nf2 2>/dev/null | head -n1)
	if [[ $nf3 != $nf1 ]] ; then
		rm $JobCtrlDir/SGE_JobData
		. $JobDataBuild
		fi 
# test sur la version du script
	nf2=${JobDataBuild}
	nf3=$(ls -dt $nf1 $nf2 2>/dev/null | head -n1)
	if [[ $nf3 != $nf1 ]] ; then
		rm $JobCtrlDir/SGE_JobData
		. $JobDataBuild
		fi 
  else
	. $JobDataBuild 
fi

# Lecture du fichier SGE_JobData
il=0     # indice de ligne du fichier SGE_JobData
ih=0
while read line; do
	il=`expr $il + 1`
	if [[ $il -eq 1 ]] ; then
		read methode < <(echo $line)
	elif [[ $il -eq 2 ]] ; then
		read SCORRECT MDQ commentaire < <(echo $line)
# Traitement "de faveur" des jobs a specif de queue incorrecte: 
#    la relance ne doit avoir lieu qu'apres celle des autres jobs.
		if [[ x$SCORRECT = xn ]]; then NseuilRef=${NseuilRef_special} ; fi
	elif [[ $il -eq 3 ]] ; then
#		read  MPI_TYPE MPI_SIG_CMD MPI_SOCKET MPDJOBID MPICMD_PID < <(echo $line)
		read  MOT1     MOT2        MOT3       MOT4     MOT5        < <(echo $line)
	else
		ih=`expr $ih + 1`
		read hote[$ih] nslots[$ih] PrioEff[$ih] LOAD_CORR[$ih] PIDC[$ih] CONNEXION[$ih] < <(echo $line)
		Nseuil[$ih]=$(echo "scale=2; $NseuilRef / ${LOAD_CORR[$ih]}" | bc)
		case $methode in
		 2|5)
			if [[ x${PIDC[$ih]} = xz ]] ; then 
				echo 'Probleme: methode inapplicable, absence de pid de controle'
			fi
		 	;;
		esac
		case ${PrioEff[$ih]} in P) SUBORD[$ih]=non ;; L )SUBORD[$ih]=oui ;; esac
	fi
done < $JobCtrlDir/SGE_JobData

if [[ ${NHOSTS} -ne ${ih} ]] ; then echo 'Probleme de lecture du pe_hostfile'; fi


# Fausse relance d'un job qui tourne deja.
case $methode in
  1|2|5)                 
	PIDtest=${PIDC[1]}
	;;
  3)
# ATTENTION, le PIDtest ne peut pas etre obtenu a partir de MOT5
#	treepm=$(pstree -Anlpc $MOT5 | head -n1); trash=${treepm##*(}; 
#	PIDtest=${trash%)};
	PIDtest=''
	;;
  4)
# ancienne version qui marchait avec CentOS 5.10
#	treepm=$(pstree -Anlpc $MOT1 | head -n1); trash=${treepm##*(}; 
# nouvelle version qui marche avec CentOS 6.5
	treepm=$(pstree -Anlpc $MOT1 | tail -n1); trash=${treepm#*\(}; 
	PIDtest=${trash%%\)*};
    
	;;
  *)
# A COMPLETER, pour l'instant ce n'est pas operationnel.
  	PIDtest=''
	;;
esac
if [[ x$PIDtest != x ]] ; then
	ps  -p $PIDtest -o stat |tail -n1 | sed s/STAT/stat/ | grep T
	if [ $? -ne 0 ] ; then 
		echo "Fausse relance, le job tournait deja."
		if [[ -f $Rcadenas ]] ; then rm $Rcadenas ; fi
		exit 0 
	fi
fi


# Correction d'un bug de SGE qui envoie un signal mal a propos lorsque plusieurs queues sont suspendues.
# NB: ce script est peut-etre mis en defaut si le job utilise plusieurs queues (genre prio ET big).
for h in ${hote[@]}; do 
	etat_q=$(etat_queue_instance ${h})
	echo $etat_q | grep s  1>/dev/null 2>&1
	if [  $? -eq 0 ] ; then
		echo "ERREUR SGE: L'une des queue_instances de ce job est dans l'etat $etat_q , il ne faut pas relancer."
		if [[ -f $Rcadenas ]] ; then rm $Rcadenas ; fi
		mise_a_jour_affichage_s
		echo "bye bye " $(date)
		exit 0
	fi 
done


# La relance est-elle conditionnee a la charge des noeuds ou pas?
relanceConditionnelle=oui
echo ${PrioEff[*]} | grep "L" 2>/dev/null 1>&2
if [ $? -ne 0 ] ; then 
	relanceConditionnelle=non
	echo ${PrioEff[*]} | grep "B" 2>/dev/null 1>&2
	if [ $? -eq 0 ] ; then relanceConditionnelle=peutetre ; fi
fi

# Introduction d'une desynchronisation entre les jobs en competition.
# Ce "sleep" est inutile si nsuspend=1.
case  $relanceConditionnelle in
  non)
	BLOCAGE=0
	delai=$(echo | awk '{srand(); print 2+3*rand()}' | tr , .)
	;;
  peutetre)
 	BLOCAGE=1
	delaiAle=$(echo | awk '{srand(); print 10*rand()}' | tr , .)
#	sleep ${delaiAle}
	delai=$(echo "15 + ${delaiAle}" | bc)
	;;
  oui)
 	BLOCAGE=1
	delaiAle=$(echo | awk '{srand(); print 40*rand()}' | tr , .)
#	sleep ${delaiAle}
	delai=$(echo "25 + ${delaiAle}" | bc)
	;;
esac
  
if [[ $SCORRECT = n ]] ; then 
	relanceConditionnelle=oui 
 	BLOCAGE=1
	delai=$(echo | awk '{srand(); print 119+10*rand()}' | tr , .)
	echo 'Attention, priorite degradee car le job utilise plusieurs queues sur un meme noeud.'
fi

# Gande boucle d'attente de la liberation des ressources.
while [[ x$BLOCAGE = x1 ]] ; do
	BLOCAGE=0
# Recherche de jobs en queue prio*.q entrainant la subordination.
# ATTENTION, il ne peut pas y avoir subordination a des processus non geres par SGE.
	if [[ $relanceConditionnelle = peutetre ]]; then
		for  (( i=1 ; i<=${NHOSTS} ; i++ )); do 
			if [[ ${PrioEff[$i]} = B ]] ; then
				jup=$($SGE_bin/qstat -q ${QueuePrio}*@${hote[$i]} -f |eval awk \'/${hote[$i]%%.*}/ {print \$3}\' | cut -d/ -f2 )
				jub=$($SGE_bin/qstat -q ${QueueMixte}*@${hote[$i]} -f |eval awk \'/${hote[$i]%%.*}/ {print \$3}\' | cut -d/ -f2 )
				jupb=$(( $jup + $jub ))
				if [[ $jupb -gt $coresPerNode ]] ; then SUBORD[$i]=oui ; else SUBORD[$i]=non ; fi
			fi
		done
		echo ${SUBORD[*]} | grep oui 2>/dev/null 1>&2
		if [ $? -ne 0 ]; then relanceConditionnelle=non ; fi
	fi
# La charge conditionne-t-elle la relance?
	Ncritique=0
	if [[ $relanceConditionnelle != non ]]; then
		for  (( i=1 ; i<=${NHOSTS} ; i++ )); do
		 	if [[ x${SUBORD[$i]} = xoui ]] ; then
				read los lom lol blabla < <(${CONNEXION[$i]} cat /proc/loadavg)
				if [[ ${nslots[$i]} -eq 1 ]] ; then
					charge=$(echo "a=$los; b=$lom; c=$lol; " 'x=b+(a>b)*(a-b); c+(x>c)*(x-c)' | bc )
				elif [[ ${nslots[$i]} -le 5 ]] ; then
					charge=$(echo "a=$los; b=$lom; " 'b+(a>b)*(a-b)' | bc )
				else
					charge=$los
				fi
				marge=$(echo "scale=2; ${Nseuil[$i]} - $charge - ${nslots[$i]} " | bc )
				echo $marge |  grep '-' 2>/dev/null 1>&2
				if [ $? -eq 0 ]; then 
					Ncritique=1
					echo "noeud critique: " ${hote[$i]} "   Marge=" ${marge} ", le " $(date)
					break
				fi
			fi
		done
	fi 

# Si un etat S est affiche par qstat, ne pas relancer le job et sortir.
	etatSGE=$(etat_affiche_par_SGE)
	if [[ x$etatSGE = xS ]] ; then
		if [[ -f $Scadenas ]] ; then 
				rm $Scadenas 
			else
				echo 'Bizarre, il manque un Scadenas.'
		fi
		if [[ -f $Rcadenas ]] ; then rm $Rcadenas ; fi
		echo 'Pas de relance, car toute la queue vient d etre suspendue.'
		echo "bye bye " $(date)
		exit 0
	fi

# Si l etat contient S et autre chose, decider le blocage de la relance,
#    ce qui remet les compteurs a zero...
	echo $etatSGE  | grep S 1>/dev/null 2>&1
	if [ $? -eq 0 ] ; then
#		BLOCAGE=1
		echo 'Toute la queue est actuellement suspendue.'
		if [[ -f $Rcadenas ]] ; then rm $Rcadenas ; fi
		echo "bye bye " $(date)
# faire disparaitre un eventuel affichage "S"
		exec $SGE_bin/qmod -usj $JOB_ID	1>/dev/null	
		exit 0
	elif [[ $Ncritique -gt 0 ]] ; then
		BLOCAGE=1
#		echo "nb de noeuds critiques"  $Ncritique " a " $(date) 
#		eval "${CONNEXION[$i]} uptime"   # eviter l impression a chaque fois...
		mise_a_jour_affichage_s
	fi

# Si il y a une demande de suspension en attente, annihilation des signaux.
#  En principe ce cas ne devrait plus se presenter que dans des cas rares...
	if [[ -f $Scadenas ]] ; then
		rm $Scadenas
		if [[ -f $Rcadenas ]] ; then rm $Rcadenas ; fi
		echo
		echo " Cette demande de relance a ete suivie d'un contrordre."
		echo "bye bye " $(date)
		exit 0
	fi

# Bon, il est temps de dormir un peu.
	if [ $BLOCAGE -eq 1 ] ; then
		sleep $delai
	fi

# Cas ou le job a ete tue durant une suspension. Il faut faire un peu de nettoyage, 
#  incluant l envoi d un signal de relance sur les noeuds secondaires, ce qui les rendra sensibles au TERM. 
	nomjob=$(ps -p $job_pid -o comm=)
	if [[ blabla${nomjob} = blabla ]] ; then
		if [[ -f $Rcadenas ]] ; then rm $Rcadenas ; fi
		echo
		echo " le job $job_pid a ete tue, mais c est pas de ma faute"
		for (( i=1 ; i<=${NHOSTS} ; i++ )) ; do 
			if [[ ${hote[$i]%%.*} != $ici_short && x${PIDC[$i]} != xz ]] ; then 
				eval "${CONNEXION[$i]} kill -CONT -- ${PIDC[$i]} 2>/dev/null &"
			fi
		done		
		echo "bye bye " $(date)
		exit 0
	fi
done

# La charge est redescendue suffisamment et la queue n est pas suspendue. 
echo "RELANCE du job"
case $methode in
  1)                 
# signal envoye au script soumis a SGE
	kill -CONT -- -$job_pid
	;;
  2)                 
# signal envoye au processus parent sur chaque noeud
	for (( i=1 ; i<=${NHOSTS} ; i++ )) ; do 
		eval "${CONNEXION[$i]} kill -CONT -- -${PIDC[$i]} &"
	done
	;;
  3)                 
# signal envoye par le truchement de l anneau de demons MPD
    MPI_TYPE=$MOT1
	export I_MPI_ROOT=$MOT2
	export I_MPI_MPD_TMPDIR=$MOT3
	export I_MPI_JOB_CONTEXT=$MOT4
# syntaxe tres souple qui admet STOP SIGSTOP SIGSTOP, voire TSTP
	ACTION=CONT     
# ATTENTION: on identifie le jobid par simplement "1" car MatStu cree un anneau de demons mpd par job.
	${I_MPI_ROOT}/bin/mpdsigjob $ACTION -j 1
	;;
  4)                 
# signal CONT envoye a mpirun en tant que processus simple
  	eval "kill -CONT -- ${PIDC[1]} &"
	;;
  5)                 
# signal CONT envoye a chaque process group leader
	for (( i=1 ; i<=${NHOSTS} ; i++ )) ; do 
		eval "${CONNEXION[$i]} kill -CONT -- -${PIDC[$i]} &"
	done
	;;
  6|7)                 
# signal CONT envoye au process pmi_proxy du noeud de lancement
	eval "kill -CONT -- -${PIDC[1]} &"
	;;
esac

if [[ -f $Rcadenas ]] ; then rm $Rcadenas ; fi

echo "bye bye, le " $(date)

} > ${fichier_sortie}

# Lancement d un script "dummy" - voir en tete - pour mettre a jour 
#           l affichage SGE : le job est maintenant running.
# LIGNES A RETRAVAILLER car parfois SGE ne relance pas le exec qmod -usj .
etatSGE=$(etat_affiche_par_SGE)
echo $etatSGE   | grep s 1>/dev/null 2>&1
if [ $? -eq 0 ] ; then
###	echo "je pose un cadenas DUMMY" 1>&2
	touch  $Dcadenas
	sleep 2          
###	ls -l  $Dcadenas  1>&2
###	echo "Je lance resume_meth.sh" 1>&2
	eval "$SGE_bin/qmod -usj $JOB_ID"
	sleep 2
	if [[ -f $Dcadenas ]] ; then rm $Dcadenas ; fi 
###		echo "Pour info: SGE n a pas relance le script resume_meth.sh..." 1>&2
fi
